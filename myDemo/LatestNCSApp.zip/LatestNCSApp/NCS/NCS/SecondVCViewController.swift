//
//  SecondVCViewController.swift
//  NCS
//
//  Created by mac on 15/11/21.
//

import UIKit
import YoutubePlayer_in_WKWebView

class SecondVCViewController: UIViewController
{

    
   
    @IBOutlet weak var Player: WKYTPlayerView!
    
    
    @IBOutlet weak var videoHelperTable: UITableView!
    
    var helperVideoArr : Array = ["Career Centre","Councellar","Employer","Government Department","Jobseeker"]
    
    
    override func viewDidLoad() {
           super.viewDidLoad()
        
        
        Player.isHidden = true
      //  Player.load(withVideoId: "IEm_-SyWo40")
        
      //  Player.delegate = self
       }
    
}

extension SecondVCViewController : WKYTPlayerViewDelegate
{
    func playerViewDidBecomeReady(_ playerView: WKYTPlayerView) {
        playerView.playVideo()
    }
}
extension SecondVCViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return helperVideoArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NCSTableViewCell") as! NCSTableViewCell
        
        cell.NCSTextLbl.text = helperVideoArr[indexPath.row]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch(indexPath.row)
        {
        case 0 :   Player.isHidden = false
                   Player.load(withVideoId: "ypmJ4a-D5Jk")
            
        case 1 :   Player.isHidden = false
                   Player.load(withVideoId: "taEl7Nb1t9A")
            
        case 2 :   Player.isHidden = false
                   Player.load(withVideoId: "15m6mphAuk4")
            
        case 3 :   Player.isHidden = false
                   Player.load(withVideoId: "Za0p5n9HV6s")
            
        case 4 :   Player.isHidden = false
                   Player.load(withVideoId: "IEm_-SyWo40")
            
            
        default:Player.isHidden = true
            
        }
    }
    
  
    
    
}
