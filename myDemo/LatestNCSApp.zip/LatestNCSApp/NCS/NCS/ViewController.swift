//
//  ViewController.swift
//  NCS
//
//  Created by mac on 12/11/21.
//

import UIKit
import QuartzCore
import MarqueeLabel

class ViewController: UIViewController {
    
    
    @IBOutlet weak var scrollingTxtLbl: MarqueeLabel!
    
    @IBOutlet weak var userNameTxt: UITextField!
    
    @IBOutlet weak var passwordTxt: UITextField!
    
    @IBOutlet weak var signInBtnOutlet: UIButton!
    
    @IBOutlet weak var signUpBtnOutlet: UIButton!
    
    
    @IBOutlet weak var loginContainerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollingTxtLbl.type = .continuous
        scrollingTxtLbl.scrollDuration = 20
        scrollingTxtLbl.animationCurve = .easeOut
        scrollingTxtLbl.fadeLength = 10.0
        scrollingTxtLbl.leadingBuffer = 30.0
        scrollingTxtLbl.trailingBuffer = 20.0
        
        loginContainerView.clipsToBounds = true
        loginContainerView.layer.cornerRadius = 5
        loginContainerView.layer.borderWidth = 1
        loginContainerView.layer.borderColor = UIColor.clear.cgColor
        
       
        
        userNameTxt.addViewBorder(borderColor: #colorLiteral(red: 180/255, green: 190/255, blue: 195/255, alpha: 1), borderWith: 1.0, borderCornerRadius: 5)
        
        passwordTxt.addViewBorder(borderColor: #colorLiteral(red: 180/255, green: 190/255, blue: 195/255, alpha: 1), borderWith: 1.0, borderCornerRadius: 5)
        
        signInBtnOutlet.addViewBorder(borderColor: #colorLiteral(red: 47/255, green: 104/255, blue: 175/255, alpha: 1), borderWith: 1.0, borderCornerRadius: 5)
        
        signUpBtnOutlet.addViewBorder(borderColor: #colorLiteral(red: 236/255, green: 167/255, blue: 69/255, alpha: 1), borderWith: 1.0, borderCornerRadius: 5)
        
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        self.navigationController?.navigationBar.isTranslucent = true
        
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        self.hideKeyboardWhenTappedAround()
        
        
        self.userNameTxt.setupLeftImage(imageName: "userIcon")
        
        self.passwordTxt.setupLeftImage(imageName: "pwd")
      
        
      //  UIApplication.statusBarBackgroundColor = .blue
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    self.navigationController?.isNavigationBarHidden = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    self.navigationController?.isNavigationBarHidden = false
    }
    
    
    
    @IBAction func forgotPassworwordBtnClk(_ sender: Any) {
  
        let vc = (storyboard!.instantiateViewController(identifier: "ActivateAccountViewController")) as! ActivateAccountViewController
                   
                 //  vc.detailTextStr = informationArr[indexPath.row].data
                   
                        self.navigationController?.pushViewController(vc, animated: true)
    
    }
    
    @IBAction func forgotUserNameBtnClk(_ sender: UIButton) {
        
        let vc = (storyboard!.instantiateViewController(identifier: "ActivateAccountViewController")) as! ActivateAccountViewController
        
        sharedItems.shared.commingFrom = "forgotUserName"
                   
                 //  vc.detailTextStr = informationArr[indexPath.row].data
                   
                        self.navigationController?.pushViewController(vc, animated: true)
    
        
    }
    
    
   

}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

//----------

extension UITextField {

    //MARK:- Set Image on the right of text fields

  func setupRightImage(imageName:String){
    let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 20, height: 20))
    imageView.image = UIImage(named: imageName)
    let imageContainerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 37, height: 40))// w:55
    imageContainerView.addSubview(imageView)
    rightView = imageContainerView
    rightViewMode = .always
    self.tintColor = .lightGray
}

 //MARK:- Set Image on left of text fields

    func setupLeftImage(imageName:String){
       let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 20, height: 20))
       imageView.image = UIImage(named: imageName)
       let imageContainerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 35, height: 40))
       imageContainerView.addSubview(imageView)
       leftView = imageContainerView
       leftViewMode = .always
       self.tintColor = .lightGray
     }

  }

extension UIView {
    public func addViewBorder(borderColor:CGColor,borderWith:CGFloat,borderCornerRadius:CGFloat){
        self.layer.borderWidth = borderWith
        self.layer.borderColor = borderColor
        self.layer.cornerRadius = borderCornerRadius

    }
}



