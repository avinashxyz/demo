//
//  appModel.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

struct item : Codable
{
    var item_type : String
    var data : String
}

struct items : Codable {
    var data :[item]
}

