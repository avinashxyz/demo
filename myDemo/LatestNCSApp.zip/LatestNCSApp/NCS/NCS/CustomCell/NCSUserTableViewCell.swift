//
//  NCSUserTableViewCell.swift
//  NCS
//
//  Created by mac on 17/11/21.
//

import UIKit

class NCSUserTableViewCell: UITableViewCell {

    
    @IBOutlet weak var NCSUserLbl: UILabel!
    
    @IBOutlet weak var leftImg: UIImageView!
    
    
   
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
     //   NCSUserLbl.addViewBorder(borderColor: #colorLiteral(red: 180/255, green: 190/255, blue: 195/255, alpha: 1), borderWith: 1.0, borderCornerRadius: 0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
