//
//  fetchDataViewModel.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

import Foundation
class fetchDataViewModel
{
    static func fetchLocalData(Path : String, completion:([item])->())
    {
        let jsonData = (try? String(contentsOfFile: Path).data(using: .utf8))!
        
        let decodedData = try?JSONDecoder().decode(items.self,from:jsonData)
        
        completion(decodedData?.data ?? [])
        
    }
}
