//
//  DomcoTableViewCell.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

import UIKit

class DomcoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var domcoLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
