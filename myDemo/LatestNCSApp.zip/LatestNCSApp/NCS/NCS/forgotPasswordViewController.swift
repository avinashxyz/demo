//
//  forgotPasswordViewController.swift
//  NCS
//
//  Created by mac on 17/11/21.
//

import UIKit

class forgotPasswordViewController: UIViewController {
    
    @IBOutlet weak var selectUserTableView: UITableView!
    
    
    @IBOutlet weak var lblContainer: UIView!
    
    
    @IBOutlet weak var IAmLbl: UILabel!
    
    
    @IBOutlet weak var selectUserBtn: UIButton!
    
    
    
    @IBOutlet var selectedUserImg: UIImageView!
    
    
    var userArr : Array = ["Jobseeker","Employer","Local Services","Household Users","Skill Provider", "Placement Organisation","Government Department"]
    
    var userIconArr : Array = ["job_seekar_white","employer_icon_white","local_service_white","househild_white","skill_provider_white","Placemen_org_white","govt_dept_white"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.title = "Forgot Password"
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        self.navigationController?.navigationBar.isTranslucent = true
        
        self.navigationController?.navigationBar.tintColor = UIColor.white

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func selectUserBtnAction(_ sender: UIButton) {
        
        selectUserBtn.isHidden = true
        
        selectUserTableView.isHidden = false
    }
    

}

extension forgotPasswordViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return userArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NCSUserTableViewCell") as! NCSUserTableViewCell
        
        cell.NCSUserLbl.text = userArr[indexPath.row] //helperVideoArr[indexPath.row]
        
        if indexPath.row == 0
        {
        cell.leftImg.image = UIImage(named: "job_seekar_blck")
        }
        else if indexPath.row == 1
        {
            cell.leftImg.image = UIImage(named: "employer_icon_blc")
        }
        else if indexPath.row == 2
        {
            cell.leftImg.image = UIImage(named: "local_service_blck")
        }
        else if indexPath.row == 3
        {
            cell.leftImg.image = UIImage(named: "househild_blck")
        }
        else if indexPath.row == 4
        {
            cell.leftImg.image = UIImage(named: "skill_provider_blck")
        }
        else if indexPath.row == 5
        {
            cell.leftImg.image = UIImage(named: "Placemen_org_blck")
        }
        else if indexPath.row == 6
        {
            cell.leftImg.image = UIImage(named: "govt_dept._blck")
        }
       
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        self.selectedUserImg.image = UIImage(named: userIconArr[indexPath.row])
        
        self.IAmLbl.text = "I am : " + userArr[indexPath.row]
        
        self.selectUserTableView.isHidden = true
        
        selectUserBtn.isHidden = false
        
    }
    
}
