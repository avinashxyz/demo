//
//  ViewController.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate,UITableViewDataSource {
  
    
    
    var informationArr = [item]()
    
    @IBOutlet weak var tableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        overrideUserInterfaceStyle = .dark
        
        guard let bundlePath = Bundle.main.path(forResource: "jsonData", ofType: "json") else { return }
        
        fetchDataViewModel.fetchLocalData(Path: bundlePath) { (myData) in
            
            informationArr = myData
        }
        
        print(" data fron JSON ",informationArr[0].item_type)
        print(" data fron JSON ",informationArr[0].data)
        
        let nib = UINib(nibName: "DomcoTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "DomcoTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return informationArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DomcoTableViewCell") as! DomcoTableViewCell
        cell.domcoLabel.text = informationArr[indexPath.row].item_type
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        
        switch(indexPath.row)
        {
        case 0 :
                 let vc = (storyboard.instantiateViewController(identifier:    "detailTextViewController")) as! detailTextViewController
            
            vc.detailTextStr = informationArr[indexPath.row].data
            
                 self.navigationController?.pushViewController(vc, animated: true)
            
            
            
            
    case 1 :let vc = (storyboard.instantiateViewController(identifier:    "detailURLViewController")) as!   detailURLViewController
        
        vc.DetailURLStr = informationArr[indexPath.row].data
            
        self.navigationController?.pushViewController(vc, animated: true)
       
    case 2 : let vc = (storyboard.instantiateViewController(identifier:    "detailImageViewController")) as! detailImageViewController
        
        vc.domcoImageURL = informationArr[indexPath.row].data
        
        self.navigationController?.pushViewController(vc, animated: true)
    
    case 3 : let vc = (storyboard.instantiateViewController(identifier:    "detailVideoViewController")) as! detailVideoViewController
        
        vc.VideoURL = informationArr[indexPath.row].data
        
        self.navigationController?.pushViewController(vc, animated: true)
            
        
       
    default: print("no case found")
        }
        
        
    }


}

