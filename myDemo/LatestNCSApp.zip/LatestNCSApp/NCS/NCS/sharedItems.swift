//
//  sharedItems.swift
//  NCS
//
//  Created by mac on 26/11/21.
//

import Foundation
class sharedItems
{
    static let shared = sharedItems()
    
    var commingFrom = ""
    
    private init() {
        
    }
}
