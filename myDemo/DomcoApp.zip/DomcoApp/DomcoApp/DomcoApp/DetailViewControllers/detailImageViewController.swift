//
//  detailImageViewController.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

import UIKit

class detailImageViewController: UIViewController {

    
    @IBOutlet weak var detailImageView: UIImageView!
    
    var domcoImageURL : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        print("domco image url :\(domcoImageURL)")
        // Do any additional setup after loading the view.
        
        let url = URL(string: domcoImageURL)!
        
        let dataTask = URLSession.shared.dataTask(with:url)
        {
            (data,_,_) in
            
            if let data = data {
                DispatchQueue.main.async {
                    self.detailImageView.image = UIImage(data: data)
                }
            }
        }
        dataTask.resume()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
