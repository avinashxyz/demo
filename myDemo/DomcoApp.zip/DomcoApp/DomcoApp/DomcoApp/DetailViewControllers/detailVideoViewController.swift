//
//  detailVideoViewController.swift
//  DomcoApp
//
//  Created by AVINASH on 25/09/21.
//

import UIKit
import AVKit

class detailVideoViewController: UIViewController {
    
    
    @IBOutlet weak var videoView: UIView!
    
    var VideoURL: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("video URL : \(VideoURL)")

       if let myVideoURL = URL(string: VideoURL)
       { var player:AVPlayer?
        
        player = AVPlayer(url:myVideoURL)
        
        let playerFrame = CGRect(x: 0, y: 0, width: videoView.frame.width, height: videoView.frame.height)
        
        let playerViewController = AVPlayerViewController()
        
        playerViewController.player = player
        
        playerViewController.view.frame = playerFrame
        
        addChild(playerViewController)
        
        videoView.addSubview(playerViewController.view)
        
        playerViewController.didMove(toParent: self)
       }
    }
}
