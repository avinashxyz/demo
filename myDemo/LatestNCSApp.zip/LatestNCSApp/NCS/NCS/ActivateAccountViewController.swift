//
//  ActivateAccountViewController.swift
//  NCS
//
//  Created by mac on 17/11/21.
//

import UIKit

class ActivateAccountViewController: UIViewController {
    
    
    @IBOutlet weak var IamHeaderText: UILabel!
    
    
    @IBOutlet weak var FirstNameHeaderText: UILabel!
    
    
    @IBOutlet weak var FathersNameHeaderText: UILabel!
    
    
    @IBOutlet weak var DOBHeaderText: UILabel!
    
    @IBOutlet weak var MobileNumberHeaderText: UILabel!
    
    
    @IBOutlet var mobileNumberHeader: UILabel!
    
    @IBOutlet weak var SecurityCodeHeaderText: UILabel!
    
    @IBOutlet weak var securityCodeContainer: UIView!
    
    @IBOutlet weak var captchaContainer: UIView!
    
    @IBOutlet weak var captchaTxt: UITextField!
    
    @IBOutlet weak var captchaLbl: UILabel!
    
    
    @IBOutlet var captchaLblForGovt: UILabel!
    
    @IBOutlet weak var generateOTPOutlet: UIButton!
    
    @IBOutlet weak var IamContainerView: UIView!
    
    @IBOutlet weak var IAmLbl: UILabel!
    
    @IBOutlet weak var NCSUserTableView: UITableView!
    
    @IBOutlet weak var selectUserBtnOutlet: UIButton!
    
    @IBOutlet weak var jobseekerView: UIView!
    
    
    @IBOutlet var GovernmentDept: UIView!
    
    @IBOutlet var generate_OTP_For_Govt_outlet: UIButton!
    
    
    @IBOutlet var NCS_ID_For_govt: UILabel!
    
    @IBOutlet var emailHeader: UILabel!
    
    
    @IBOutlet var captchaTxtForJobSeeker: UITextField!
    

    
    
    var alphas :[String] = []
    
    var captchaString = ""
    
    var i1: Int = 0
    var i2: Int = 0
    var i3: Int = 0
    var i4: Int = 0
    var i5: Int = 0
    
    
    
    var userArr : Array = ["Jobseeker","Employer","Local Services","Household Users","Skill Provider","CounSeller", "Placement Organisation","Government Department"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(sharedItems.shared.commingFrom)
        if sharedItems.shared.commingFrom == "forgotUserName"
        {
        self.title = "Forgot Username"
            
            sharedItems.shared.commingFrom = "###"
        }
        else{
            self.title = "Activate Account"
        }
        
        alphas = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
        
       // IamHeaderText = "Hello Test"
    IamHeaderText.halfTextColorChange(fullText: "I am*", changeText: "*")
        
    FirstNameHeaderText.halfTextColorChange(fullText: "First Name*", changeText: "*")
        
    DOBHeaderText.halfTextColorChange(fullText: "Date of Birth*", changeText: "*")
        
    MobileNumberHeaderText.halfTextColorChange(fullText: "Mobile Number*", changeText: "*")
        
    SecurityCodeHeaderText.halfTextColorChange(fullText: "Enter Security Code*", changeText: "*")
        
    NCS_ID_For_govt.halfTextColorChange(fullText: "NCS ID*", changeText: "*")
        
    emailHeader.halfTextColorChange(fullText: "Email*", changeText: "*")
        
    mobileNumberHeader.halfTextColorChange(fullText: "Mobile Number*", changeText: "*")
        
//        let strNumber: NSString = "I am*" as NSString // you must set your
//        let range = (strNumber).range(of: "*")
//        let attribute = NSMutableAttributedString.init(string: strNumber as String)
//        attribute.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red , range: range)
//
//        IamHeaderText.attributedText = attribute
        

        jobseekerView.isHidden = true
        
        
        
        IamContainerView.backgroundColor = .clear
        
        selectUserBtnOutlet.isHidden = true
        IAmLbl.clipsToBounds = true
        IAmLbl.layer.cornerRadius = 5 // 10
        IAmLbl.layer.borderWidth = 1
        IAmLbl.layer.borderColor = UIColor.black.cgColor
        
        NCSUserTableView.isHidden = false
        
        securityCodeContainer.clipsToBounds = true
        securityCodeContainer.layer.cornerRadius =  5 //10
        securityCodeContainer.layer.borderWidth = 1
        securityCodeContainer.layer.borderColor = UIColor.black.cgColor
        
        captchaContainer.clipsToBounds = true
        captchaContainer.layer.cornerRadius = 5 //10
        captchaContainer.layer.borderWidth = 1
        captchaContainer.layer.borderColor = UIColor.black.cgColor
        
        generateOTPOutlet.clipsToBounds = true
        generateOTPOutlet.layer.cornerRadius = 5
        generateOTPOutlet.layer.borderWidth = 1
        generateOTPOutlet.layer.borderColor = UIColor.black.cgColor
        
        generate_OTP_For_Govt_outlet.clipsToBounds = true
        generate_OTP_For_Govt_outlet.layer.cornerRadius = 5
        generate_OTP_For_Govt_outlet.layer.borderWidth = 1
        generate_OTP_For_Govt_outlet.layer.borderColor = UIColor.black.cgColor
        
        
        captchaTxt.backgroundColor = .white
        
        captchaTxtForJobSeeker.backgroundColor = .white
        // Do any additional setup after loading the view.
    }
    
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    
     }
    */
    override func viewWillAppear(_ animated: Bool) {
        reloadCaptcha()
    }
    
    
    @IBAction func selectedUserBtnAction(_ sender: UIButton) {
        
        selectUserBtnOutlet.isHidden = false
        
        NCSUserTableView.isHidden = false
        
        self.IAmLbl.text =  "----Select----"
        
        self.IAmLbl.textAlignment = .center
        
    }
    
    func reloadCaptcha()
    {
        i1 = Int(arc4random()) % alphas.count
        i2 = Int(arc4random()) % alphas.count
        i3 = Int(arc4random()) % alphas.count
        i4 = Int(arc4random()) % alphas.count
        i5 = Int(arc4random()) % alphas.count
        
        captchaString = "\(alphas[i1])\(alphas[i2])\(alphas[i3])\(alphas[i4])\(alphas[i5])"
        
        captchaLbl.text = captchaString
        
        captchaLblForGovt.text = captchaString
        
        print(captchaString)
        
    }
    
    @IBAction func generateCaptchaAction(_ sender: UIButton) {
        
        reloadCaptcha()
    }
    
    
}


extension ActivateAccountViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return userArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NCSUserTableViewCell") as! NCSUserTableViewCell
        
        cell.NCSUserLbl.text = userArr[indexPath.row] //helperVideoArr[indexPath.row]
        
        if indexPath.row == 0
        {
        cell.leftImg.image = UIImage(named: "job_seekar_blck")
        }
        else if indexPath.row == 1
        {
            cell.leftImg.image = UIImage(named: "employer_icon_blc")
        }
        else if indexPath.row == 2
        {
            cell.leftImg.image = UIImage(named: "local_service_blck")
        }
        else if indexPath.row == 3
        {
            cell.leftImg.image = UIImage(named: "househild_blck")
        }
        else if indexPath.row == 4
        {
            cell.leftImg.image = UIImage(named: "skill_provider_blck")
        }
        else if indexPath.row == 5
        {
            cell.leftImg.image = UIImage(named: "Placemen_org_blck")
        }
        else if indexPath.row == 6
        {
            cell.leftImg.image = UIImage(named: "govt_dept._blck")
        }
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        self.IAmLbl.text =  "  " + userArr[indexPath.row]
        
        self.IAmLbl.textAlignment = .left
        
        
        if(indexPath.row == 0||indexPath.row == 5 || indexPath.row == 2)
        {
            
            self.NCSUserTableView.isHidden = true
            
            GovernmentDept.isHidden = true
        
            selectUserBtnOutlet.isHidden = false
        
           jobseekerView.isHidden = false
            
            
            
            reloadCaptcha()
        }
        else if indexPath.row == 7
        {
            self.NCSUserTableView.isHidden = true
        
            selectUserBtnOutlet.isHidden = false
        
           jobseekerView.isHidden = true
            
            GovernmentDept.isHidden = false
            
            
        }
        
    }
    
}

extension UILabel {
    func halfTextColorChange (fullText : String , changeText : String ) {
        let strNumber: NSString = fullText as NSString
        let range = (strNumber).range(of: changeText)
        let attribute = NSMutableAttributedString.init(string: fullText)
        attribute.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red , range: range)
        self.attributedText = attribute
    }
}
