//
//  SignUpViewController.swift
//  NCS
//
//  Created by mac on 17/11/21.
//

import UIKit

class SignUpViewController: UIViewController {
    
    
    @IBOutlet weak var RegisterAsTableView: UITableView!
    
    var registerAsArr : Array = ["Jobseeker","Employer","Local Services","Household Users","Skill Provider", "Placement Organisation","Government Department"]
    
    
    var userIconArr : Array = ["job_seekar_blck","employer_icon_blc","local_service_blck","househild_blck","skill_provider_blck","Placemen_org_blck","govt_dept._blck"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension SignUpViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return registerAsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NCSSignUpTableViewCell") as! NCSSignUpTableViewCell
        
        cell.NCSRegisterSelectLbl.text = registerAsArr[indexPath.row] //helperVideoArr[indexPath.row]
        
        cell.letfImage.image = UIImage(named:userIconArr[indexPath.row])
        
        return cell
        
    }
    
}
